-- MySQL dump 10.13  Distrib 5.5.42, for Linux (x86_64)
--
-- Host: localhost    Database: msoeslmt_servicemanagementtool
-- ------------------------------------------------------
-- Server version	5.5.42-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Profile_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `System_Privileges_id` int(11) NOT NULL,
  `reported` int(11) DEFAULT '0',
  `is_banned` tinyint(1) DEFAULT '0',
  `security_question` varchar(255) NOT NULL,
  `security_answer` varchar(255) DEFAULT NULL,
  `recieve_emails` tinyint(1) DEFAULT '1',
  `defend_suspension` tinyint(1) DEFAULT NULL,
  `locked_code` int(11) DEFAULT '-1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  UNIQUE KEY `email_address_UNIQUE` (`email_address`),
  KEY `fk_Account_Profile1_idx` (`Profile_id`),
  KEY `fk_Account_System_Privileges1_idx` (`System_Privileges_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`id`, `Profile_id`, `username`, `password`, `email_address`, `System_Privileges_id`, `reported`, `is_banned`, `security_question`, `security_answer`, `recieve_emails`, `defend_suspension`, `locked_code`) VALUES (10,10,'admin','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8','leitzke@msoe.edu',22,0,0,'What was the Senior Design Team name that created this application?','ateam',1,NULL,7378054);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_has_skills`
--

DROP TABLE IF EXISTS `account_has_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_has_skills` (
  `Account_id` int(11) NOT NULL,
  `Skills_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `fk_Account_has_Skills_Skills1_idx` (`Skills_id`),
  KEY `fk_Account_has_Skills_Account_idx` (`Account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_has_skills`
--

LOCK TABLES `account_has_skills` WRITE;
/*!40000 ALTER TABLE `account_has_skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_has_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_subscribes_to_forum`
--

DROP TABLE IF EXISTS `account_subscribes_to_forum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_subscribes_to_forum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `forum_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_subscribes_to_forum`
--

LOCK TABLES `account_subscribes_to_forum` WRITE;
/*!40000 ALTER TABLE `account_subscribes_to_forum` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_subscribes_to_forum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_subscribes_to_thread`
--

DROP TABLE IF EXISTS `account_subscribes_to_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_subscribes_to_thread` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `thread_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_subscribes_to_thread`
--

LOCK TABLES `account_subscribes_to_thread` WRITE;
/*!40000 ALTER TABLE `account_subscribes_to_thread` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_subscribes_to_thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_title`
--

DROP TABLE IF EXISTS `account_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_title` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_title`
--

LOCK TABLES `account_title` WRITE;
/*!40000 ALTER TABLE `account_title` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banner`
--

DROP TABLE IF EXISTS `banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort_order` int(11) DEFAULT '1000',
  `alt_text` varchar(255) DEFAULT NULL,
  `src` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `url` varchar(255) DEFAULT '#',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner`
--

LOCK TABLES `banner` WRITE;
/*!40000 ALTER TABLE `banner` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `endorsement`
--

DROP TABLE IF EXISTS `endorsement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `endorsement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Account_has_Skills_id` int(11) NOT NULL,
  `Account_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Endorsement_Account_has_Skills1_idx` (`Account_has_Skills_id`),
  KEY `fk_Endorsement_Account1_idx` (`Account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `endorsement`
--

LOCK TABLES `endorsement` WRITE;
/*!40000 ALTER TABLE `endorsement` DISABLE KEYS */;
/*!40000 ALTER TABLE `endorsement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date_time` datetime NOT NULL,
  `description` text NOT NULL,
  `event_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_has_account`
--

DROP TABLE IF EXISTS `event_has_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_has_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `account_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_has_account`
--

LOCK TABLES `event_has_account` WRITE;
/*!40000 ALTER TABLE `event_has_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_has_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `frequently_asked_questions`
--

DROP TABLE IF EXISTS `frequently_asked_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `frequently_asked_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `frequently_asked_questions`
--

LOCK TABLES `frequently_asked_questions` WRITE;
/*!40000 ALTER TABLE `frequently_asked_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `frequently_asked_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friend_request`
--

DROP TABLE IF EXISTS `friend_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friend_request` (
  `friend_requestee` int(11) NOT NULL,
  `friend_requestor` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `new` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_Account_has_Account_Account1_idx` (`friend_requestee`),
  KEY `fk_Account_has_Account_Account2_idx` (`friend_requestor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friend_request`
--

LOCK TABLES `friend_request` WRITE;
/*!40000 ALTER TABLE `friend_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `friend_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friends`
--

DROP TABLE IF EXISTS `friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friends` (
  `Account_id1` int(11) NOT NULL,
  `Account_id2` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `fk_Account_has_Account_Account1_idx` (`Account_id1`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friends`
--

LOCK TABLES `friends` WRITE;
/*!40000 ALTER TABLE `friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invite_permission`
--

DROP TABLE IF EXISTS `invite_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invite_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invite_status` int(1) DEFAULT '0',
  `new` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invite_permission`
--

LOCK TABLES `invite_permission` WRITE;
/*!40000 ALTER TABLE `invite_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `invite_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_comment`
--

DROP TABLE IF EXISTS `lesson_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lesson_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text,
  `upvotes` int(11) DEFAULT '0',
  `inappropriate` int(11) DEFAULT '0',
  `Lesson_Learned_id` int(11) NOT NULL,
  `Lesson_Comment_id` int(11) NOT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Lesson_Comment_Lesson_Learned1_idx` (`Lesson_Learned_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lesson_comment`
--

LOCK TABLES `lesson_comment` WRITE;
/*!40000 ALTER TABLE `lesson_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_learned`
--

DROP TABLE IF EXISTS `lesson_learned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lesson_learned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage_3_id` int(11) NOT NULL,
  `lesson` text NOT NULL,
  `upvotes` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_Lesson_Learned_stage_41_idx` (`stage_3_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lesson_learned`
--

LOCK TABLES `lesson_learned` WRITE;
/*!40000 ALTER TABLE `lesson_learned` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_learned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `picture`
--

DROP TABLE IF EXISTS `picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `picture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `picture`
--

LOCK TABLES `picture` WRITE;
/*!40000 ALTER TABLE `picture` DISABLE KEYS */;
/*!40000 ALTER TABLE `picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problem_solution`
--

DROP TABLE IF EXISTS `problem_solution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `problem_solution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solution_content` text,
  `proposed_on` datetime DEFAULT NULL,
  `upvotes` int(11) DEFAULT '0',
  `stage_2_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Problem_Solution_stage_21_idx` (`stage_2_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problem_solution`
--

LOCK TABLES `problem_solution` WRITE;
/*!40000 ALTER TABLE `problem_solution` DISABLE KEYS */;
/*!40000 ALTER TABLE `problem_solution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `about_me` text,
  `is_private` tinyint(1) DEFAULT '0',
  `profile_pic_url` varchar(255) DEFAULT NULL,
  `cover_photo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` (`id`, `firstname`, `lastname`, `city`, `state`, `contact_number`, `age`, `gender`, `about_me`, `is_private`, `profile_pic_url`, `cover_photo`) VALUES (10,'Professor','Leitzke',NULL,'WI',NULL,NULL,'Female','SLMT Admin Account',0,'profilefiles/default/user-img.jpg',NULL);
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage_1_id` int(11) NOT NULL,
  `stage_2_id` int(11) NOT NULL,
  `stage_3_id` int(11) NOT NULL,
  `is_private` tinyint(1) DEFAULT '0',
  `project_lead_id` int(11) NOT NULL,
  `problem_title` varchar(255) DEFAULT NULL,
  `discontinued` int(11) DEFAULT '0',
  `discontinued_reason` text,
  `performance_index` float DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_Project_stage_21_idx` (`stage_2_id`),
  KEY `fk_Project_stage_31_idx` (`stage_3_id`),
  KEY `fk_Project_Account1_idx` (`project_lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` (`id`, `stage_1_id`, `stage_2_id`, `stage_3_id`, `is_private`, `project_lead_id`, `problem_title`, `discontinued`, `discontinued_reason`, `performance_index`) VALUES (37,37,37,37,0,10,'Welcome to MSOE SLMT!!',0,NULL,0);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_banner`
--

DROP TABLE IF EXISTS `project_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `alt_text` varchar(255) DEFAULT NULL,
  `src` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_banner`
--

LOCK TABLES `project_banner` WRITE;
/*!40000 ALTER TABLE `project_banner` DISABLE KEYS */;
INSERT INTO `project_banner` (`id`, `project_id`, `sort_order`, `alt_text`, `src`, `title`, `enabled`, `url`) VALUES (52,37,0,'','projectfiles/37/Desert.jpg','WIndows desert',1,'');
/*!40000 ALTER TABLE `project_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_has_account`
--

DROP TABLE IF EXISTS `project_has_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_has_account` (
  `Project_id` int(11) NOT NULL,
  `Account_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Account_Title_ID` int(11) NOT NULL,
  `Project_Privileges_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Project_has_Account_Account1_idx` (`Account_id`),
  KEY `fk_Project_has_Account_Project1_idx` (`Project_id`),
  KEY `fk_Project_has_Account_Account_Title1_idx` (`Account_Title_ID`),
  KEY `fk_Project_has_Account_Project_Privileges1_idx` (`Project_Privileges_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_has_account`
--

LOCK TABLES `project_has_account` WRITE;
/*!40000 ALTER TABLE `project_has_account` DISABLE KEYS */;
INSERT INTO `project_has_account` (`Project_id`, `Account_id`, `id`, `Account_Title_ID`, `Project_Privileges_id`) VALUES (37,10,43,1,43);
/*!40000 ALTER TABLE `project_has_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_has_picture`
--

DROP TABLE IF EXISTS `project_has_picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_has_picture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `is_profile_pic` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pic_idx` (`picture_id`),
  KEY `fk_proj_idx` (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_has_picture`
--

LOCK TABLES `project_has_picture` WRITE;
/*!40000 ALTER TABLE `project_has_picture` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_has_picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_has_skills`
--

DROP TABLE IF EXISTS `project_has_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_has_skills` (
  `Project_id` int(11) NOT NULL,
  `Skills_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `fk_Project_has_Skills_Skills1_idx` (`Skills_id`),
  KEY `fk_Project_has_Skills_Project1_idx` (`Project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_has_skills`
--

LOCK TABLES `project_has_skills` WRITE;
/*!40000 ALTER TABLE `project_has_skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_has_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_privileges`
--

DROP TABLE IF EXISTS `project_privileges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `moderate_discussions_permission` tinyint(1) DEFAULT '0',
  `edit_project_content_permission` tinyint(1) DEFAULT '0',
  `control_project_stages_permission` tinyint(1) DEFAULT '0',
  `delete_users_from_project_permission` tinyint(1) DEFAULT '0',
  `collaborator_permission` int(1) DEFAULT '0',
  `invite_permission_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_privileges`
--

LOCK TABLES `project_privileges` WRITE;
/*!40000 ALTER TABLE `project_privileges` DISABLE KEYS */;
INSERT INTO `project_privileges` (`id`, `moderate_discussions_permission`, `edit_project_content_permission`, `control_project_stages_permission`, `delete_users_from_project_permission`, `collaborator_permission`, `invite_permission_id`) VALUES (43,1,1,1,1,1,0);
/*!40000 ALTER TABLE `project_privileges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reported_by`
--

DROP TABLE IF EXISTS `reported_by`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reported_by` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reporter_id` int(11) DEFAULT NULL,
  `reported_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reported_by`
--

LOCK TABLES `reported_by` WRITE;
/*!40000 ALTER TABLE `reported_by` DISABLE KEYS */;
/*!40000 ALTER TABLE `reported_by` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skills`
--

DROP TABLE IF EXISTS `skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `skill_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skills`
--

LOCK TABLES `skills` WRITE;
/*!40000 ALTER TABLE `skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solution_comment`
--

DROP TABLE IF EXISTS `solution_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solution_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `upvotes` int(11) NOT NULL DEFAULT '0',
  `inappropriate` int(11) NOT NULL DEFAULT '0',
  `project_id` int(11) NOT NULL,
  `parent_comment_id` int(11) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `author_id` int(11) NOT NULL,
  `liked_by` text,
  `flagged_by` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solution_comment`
--

LOCK TABLES `solution_comment` WRITE;
/*!40000 ALTER TABLE `solution_comment` DISABLE KEYS */;
INSERT INTO `solution_comment` (`id`, `comment`, `upvotes`, `inappropriate`, `project_id`, `parent_comment_id`, `time`, `author_id`, `liked_by`, `flagged_by`) VALUES (15,'Welcome!',0,0,37,NULL,'2014-10-12 22:32:52',10,NULL,NULL);
/*!40000 ALTER TABLE `solution_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stage_1`
--

DROP TABLE IF EXISTS `stage_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stage_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `progress` int(11) DEFAULT '0',
  `problem_summary` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stage_1`
--

LOCK TABLES `stage_1` WRITE;
/*!40000 ALTER TABLE `stage_1` DISABLE KEYS */;
INSERT INTO `stage_1` (`id`, `progress`, `problem_summary`) VALUES (37,0,'Make yourself at home!');
/*!40000 ALTER TABLE `stage_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stage_2`
--

DROP TABLE IF EXISTS `stage_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stage_2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `progress` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stage_2`
--

LOCK TABLES `stage_2` WRITE;
/*!40000 ALTER TABLE `stage_2` DISABLE KEYS */;
INSERT INTO `stage_2` (`id`, `progress`) VALUES (37,0);
/*!40000 ALTER TABLE `stage_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stage_2_has_event`
--

DROP TABLE IF EXISTS `stage_2_has_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stage_2_has_event` (
  `stage_2_id` int(11) NOT NULL,
  `Event_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `fk_stage_3_has_Event_Event1_idx` (`Event_id`),
  KEY `fk_stage_3_has_Event_stage_31_idx` (`stage_2_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stage_2_has_event`
--

LOCK TABLES `stage_2_has_event` WRITE;
/*!40000 ALTER TABLE `stage_2_has_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `stage_2_has_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stage_3`
--

DROP TABLE IF EXISTS `stage_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stage_3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `progress` int(11) DEFAULT '0',
  `projects_achievements_summary` text,
  `what_went_wrong` text,
  `what_went_right` text,
  `future_changes` text,
  `additional_information` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stage_3`
--

LOCK TABLES `stage_3` WRITE;
/*!40000 ALTER TABLE `stage_3` DISABLE KEYS */;
INSERT INTO `stage_3` (`id`, `progress`, `projects_achievements_summary`, `what_went_wrong`, `what_went_right`, `future_changes`, `additional_information`) VALUES (37,0,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `stage_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_configurations`
--

DROP TABLE IF EXISTS `system_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_configurations` (
  `value` int(1) NOT NULL,
  `config_key` varchar(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_configurations`
--

LOCK TABLES `system_configurations` WRITE;
/*!40000 ALTER TABLE `system_configurations` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_privileges`
--

DROP TABLE IF EXISTS `system_privileges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_management_permission` tinyint(1) DEFAULT '0',
  `project_management_permission` tinyint(1) DEFAULT '0',
  `problem_submission_approval` tinyint(1) DEFAULT '0',
  `system_configuration_permission` tinyint(1) DEFAULT '0',
  `ban_users_permission` tinyint(1) DEFAULT '0',
  `system_admin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_privileges`
--

LOCK TABLES `system_privileges` WRITE;
/*!40000 ALTER TABLE `system_privileges` DISABLE KEYS */;
INSERT INTO `system_privileges` (`id`, `account_management_permission`, `project_management_permission`, `problem_submission_approval`, `system_configuration_permission`, `ban_users_permission`, `system_admin`) VALUES (22,1,1,1,1,1,1),(23,0,0,0,0,0,0),(24,0,0,0,0,0,0),(25,0,0,0,0,0,0),(26,0,0,0,0,0,0);
/*!40000 ALTER TABLE `system_privileges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teammember_accomplishment`
--

DROP TABLE IF EXISTS `teammember_accomplishment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teammember_accomplishment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stage3_id` int(11) DEFAULT NULL,
  `profile_id` int(11) DEFAULT NULL,
  `accomplishment` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teammember_accomplishment`
--

LOCK TABLES `teammember_accomplishment` WRITE;
/*!40000 ALTER TABLE `teammember_accomplishment` DISABLE KEYS */;
/*!40000 ALTER TABLE `teammember_accomplishment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thread`
--

DROP TABLE IF EXISTS `thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thread` (
  `author_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inappropriate` int(11) DEFAULT '0',
  `project_id` int(11) DEFAULT NULL,
  `disabled` tinyint(1) DEFAULT '0',
  `stickied` tinyint(1) DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thread`
--

LOCK TABLES `thread` WRITE;
/*!40000 ALTER TABLE `thread` DISABLE KEYS */;
INSERT INTO `thread` (`author_id`, `title`, `id`, `inappropriate`, `project_id`, `disabled`, `stickied`, `time`) VALUES (10,'Hello',11,0,37,0,0,'2014-10-12 16:33:02');
/*!40000 ALTER TABLE `thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thread_comment`
--

DROP TABLE IF EXISTS `thread_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thread_comment` (
  `author_id` int(11) NOT NULL,
  `comment` text,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inappropriate` int(11) DEFAULT '0',
  `parent_comment_id` int(11) DEFAULT NULL,
  `thread_id` int(11) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `upvotes` int(11) DEFAULT '0',
  `likes` int(11) DEFAULT '0',
  `liked_by` text,
  `flagged_by` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thread_comment`
--

LOCK TABLES `thread_comment` WRITE;
/*!40000 ALTER TABLE `thread_comment` DISABLE KEYS */;
INSERT INTO `thread_comment` (`author_id`, `comment`, `id`, `inappropriate`, `parent_comment_id`, `thread_id`, `time`, `upvotes`, `likes`, `liked_by`, `flagged_by`) VALUES (10,'Welcome!',16,0,NULL,11,'2014-10-12 16:33:02',0,0,NULL,NULL);
/*!40000 ALTER TABLE `thread_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'msoeslmt_servicemanagementtool'
--

--
-- Dumping routines for database 'msoeslmt_servicemanagementtool'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-07  9:29:30
