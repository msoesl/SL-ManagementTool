<div style='margin-left: auto; margin-right: auto; width: 350px;'>
	<h1 style='text-align: center;'>Page not found.</h1>
	<img alt='Please forgive us.' src='res/images/404.gif' style='margin-left: auto; margin-right: auto; width: 100%;'>
	<button data-theme="a" onclick="PageChanger.loadHomepage()">Go Home</button>
</div>