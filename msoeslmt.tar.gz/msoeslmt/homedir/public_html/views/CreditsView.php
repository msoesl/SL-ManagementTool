<?php
require_once ('import/headimportviews.php');
?>
<div class='width-80' style='margin:0 auto;max-width:1000px' data-role='content'>
	<h1 id='title'>The Innovators</h1>
	<hr>
	<p>
	<table>
		<tr>
			<td style="align: center">
				<img src="res/images/credits-Leitzke.png" style='width: 50%;' border="0" alt="Null">
			</td>
			<td>
				<h1>Dr. David Howell</h1>
			</td>
		</tr>
	</table>
	<h1 id='title'>Developers of SMT</h1>
	<hr>
	<p>
	<img src="res/images/developers.png" style='width: 100%;' border="0" alt="Null">
	<h1 id='title'>Special Thanks</h1>
	<hr>
	<p>
	<table>
		<tr>
			<td style="align: center;width:40%">
				<h3>Dr. Christopher Taylor</h3>
				<h4>Advisor</h4>
			</td>
			<td style='width:10%'></td>
			<td style='margin-left:20px;width:40%'>
				<img src="res/images/Wallace.png" style='width: 100%;' border="0" alt="Null">
				<h3>Sami Wallace</h3>
				<h4>Application Technical Writer</h4>
			</td>
		</tr>
	</table>
</div>