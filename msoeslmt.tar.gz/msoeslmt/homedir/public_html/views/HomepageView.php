<div class = 'homepage-view'>
<?php
	include('LandingPageBannerRotator.php');
	include('previewwidget.php');
?>
</div>