<?php
sleep(2);
echo "<b>Request completed successfully.</b>";