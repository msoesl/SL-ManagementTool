<?php
//setup database connection
// ORM::configure('mysql:host=xksoftwaredevelopment.com; dbname=xksoft5_servicemanagementtool');
// ORM::configure('username', 'xksoft5_smt');
// ORM::configure('password', 'servicemanagement@123');

ORM::configure('mysql:host=localhost; dbname=msoeslmt_servicemanagementtool');
ORM::configure('username', 'msoeslmt_admin');
ORM::configure('password', 'Greenleaf@123');
//Configure Primary Keys for various database tables
